/*
 * Project Name: D_H_Project_Methods.java
 * Purpose: method class that is used to minimize code. The functions in this method class are base methods that
 *          encipher from a user, decipher from a user or a datafile. the shift is always 1 denoted by the formula
 *          1 = x - (x - 1).
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/7/2018 | Time: 10:45 PM
 *
 * PSEUDO-CODE:
 *    1) declare all constants and private variables for method class use.
 *    2) create a section in which choices to can be made on which cryptic function wants to be called
 *    3) input section for getText() and keyword() methods
 *    4) create an validation for data file name
 *    5) create a reader method for the datafile
 *    6) validate the keyword and return the shift
 *    7) create encipher method()
 *    8) create decipher method()
 *    9) method to run enciphering operations
 *   10) method to run deciphering operations from user
 *   11) method to run deciphering operation from datafile.
 */
package FinalProject.CeasarSaladCipher;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class D_H_Project_Methods
{
//******************//
// Global Variables //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//******************//
  // 1) declare all constants and private variables for method class use.
  private static final String fileName = "SECRETMESSAGE.TXT";
  private static final String validKeyword = "QWERTY";
  private static final char[] ALPHABET = {
      'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
      'W', 'X', 'Y', 'Z'};
  private static String inputWord;
  private static String inputkeyword;
  private static String inputtedFileName;
  private static String file;
  private static int shift;

//*****************//
// Looping Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//*****************//
  // 2) create a section in which choices to can be made on which cryptic function wants to be called
  /**
   * Method Name: encyptionChoice()
   * Purpose: private class method that loops the choice in which there are forms to encrypt/decrypt.
   *          (fromUser/fromData) and runs the series of methods that run the encryption type.
   * Accepts: nothing
   * Returns: void, but outputs the method functions depending on choice.
   * Date: nov 18, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static void encyptionChoice()//method must be public because it is referenced in the D_H_Regular_Cipher
  {
    Scanner scanner = new Scanner(System.in);
    // Declare Variables.
    int flag = 0;
    int choiceMenu;
    int numChoice;
    
    // Create while loop to reevaluate choice after every iteration
    while (flag == 0)
    {
      //user top level explanation
      System.out.print
          (
              "(1) for enciphering (press enter)\n" +
              "(2) for deciphering (press enter)\n" +
              "(3) to exit\n" +
              "Enter 1, 2, or 3: "
          );
          
      choiceMenu = scanner.nextByte(); // (edit) using byte to make program more efficient.
      scanner.nextLine(); // buffer flush         

      // Create switch to test choiceMenu condition
      switch (choiceMenu)
      {
        case 1:
          System.out.println("We will be enciphering a message.\n");
          fromUserEncipher(choiceMenu);

        case 2:
          //insert decryption code here
          System.out.println("We will be deciphering a message.\n");
          System.out.print
              (
                  "If ciphertext will be entered via keyboard, enter 1.\n" +
                  "If ciphertext will be entered via file, enter 2.\n" +
                  "Enter 1 or 2: "
              );
          numChoice = scanner.nextByte();
          switch (numChoice)
          {
            case 1:
              fromUserDecipher(choiceMenu);
              break;
            case 2:
              fromDataDecipher(choiceMenu);
              break;
            default:
              System.out.println("Sorry this is not an input.");
          }//end switch
          break;

        case 3:
          flag += 1;
          System.out.println("<===END-PROGRAM===>"); //shows that the loop is discontinued and the program finished.
          break;

        default:
          System.out.println("Error 101: the character you typed in " +
              "does not belong to the selection\n" +
              "please try a selection of type (1,2,3)!");
      }//end switch
    }//end ---> while
    // house keeping
  }

//***************//
// Input Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//***************//

  /**
   * Method Name: infoMessageENC
   * Purpose: private class method that prints out a message to the console
   * Accepts: nothing
   * Returns: void, outputs a message used for display
   * Date: nov 18, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void infoMessageENC()
  {
    System.out.print("Enter the plaintext message you wish to encipher: ");
  }//end infoMessageEN()


  /**
   * Method Name:
   * Purpose: public class method that prints out a message to the console
   * Accepts: nothing
   * Returns: void, outputs a message used for display
   * Date: nov 18, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void infoMessageDEC()
  {
    System.out.print("Enter the plaintext message you wish to decipher: ");
  }//end infoMessageDEC()

  // 3)input section for getText() and keyword() methods
  /**
   * Method Name: getText()
   * Purpose: private class method that gets the non-ciphered input from user
   * Accepts: an int from encipherChoice()
   * Returns: String, text to be encrypted.
   * Date: nov 14, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static String getText(int choiceMenu)
  {
    //creates scanner obj
    Scanner scanner = new Scanner(System.in);
    String inputWord;
    //checks if the display message should be for enciphering or deciphering.
    switch (choiceMenu)
    {
      case 1:
        infoMessageENC();
        break;
      case 2:
        infoMessageDEC();
        break;
    }
    return inputWord = scanner.nextLine().toUpperCase();
  }//end inputWordForCypher()


  /**
   * Method Name: keyword()
   * Purpose: private class method that
   * Accepts: nothing
   * Returns: String keyword to be validated in getShift()
   * Date: Nov 11,2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static String keyword()
  {
    Scanner scanner = new Scanner(System.in); //creates a scanner
    String keyword; //declare variables
    System.out.print("Enter a keyword of only letters, with no digits, spaces, or punctuation marks: "); //input section
    return keyword = scanner.nextLine().toUpperCase();//output
  }//end keyword()

//******************//
// Datafile section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//******************//
  // 4) create an validation for data file name
  /**
   * Method Name: validateFileName()
   * Purpose: private class method used to get file name from user and validate it in readFile()
   * Accepts: nothing
   * Returns: String inpputedFileName in uppercase.
   * Date: nov 25,2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static String validateFileName()
  {
    Scanner scanner = new Scanner(System.in);
    String inputtedFileName;
    System.out.print("Enter the name of the file containing the ciphertext: ");
    return inputtedFileName = scanner.nextLine().toUpperCase();
  }


  // 5) create a reader method for the datafile
  /**
   * Method Name:
   * Purpose: private class method that gets the text from a .txt file .
   * Accepts: nothing
   * Returns: String to be enciphered.
   * Date: nov 22, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static String readFile(String inputtedFileName)
  {
    if(inputtedFileName.equals(fileName))
    {
      try
      {
        String word="";
        File fileOne = new File("secretMessage.txt");
        Scanner fileReader = new Scanner(fileOne);

        while(fileReader.hasNextLine())
        {
          word = fileReader.nextLine();
        }//end loop
        return word;
      }
      catch(FileNotFoundException ex)
      {
        System.out.println("Exception thrown, message is: " + ex.getMessage());
        //print the stack trace
        ex.printStackTrace();
        return null;
      }//end try
    }
    else
    {
      System.out.println("That file does not exist, try again.");
      readFile(inputtedFileName);
      return null;
    }
  }


//*******************//
// Frequency section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//*******************//
  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date: dec 18, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static int[] getFrequency(String token)
  {
    int[] frequencyies = new int[ALPHABET.length];
    char[] karchar = token.toCharArray();

    //cycle through the length of the phrase.
    for (int i = 0; i < token.length(); i++)
    {
      if (Character.isLetter(karchar[i]))
      {
        frequencyies[(char) (karchar[i]) - 65] += 1;
      }//end if
    }//end for

    return frequencyies;
  }//end getFrequency


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date: dec 18, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void printFrequencies(int[] frequencies, String token)
  {
    System.out.println("The frequency of the set characters in " + '"' + token + '"' + " is as follows: ");

    for (int i = 0; i < frequencies.length; i++)
    {
      System.out.println("# of " + ALPHABET[i] + "'s is " + frequencies[i] + " or "
          + (Math.floor((frequencies[i] / (double) token.length()) * 10_000) / 100) + "%");
    }//end for
    System.out.println();
  }//end printFrequencies


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date: dec 18, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static void hist(int[] frequencies)
  {
    System.out.println("<====SIMULATED-HISTOGRAM-OF-THE-FREQUENCIES====>");
    String[] histArray = new String[ALPHABET.length];
    for (int i = 0; i < frequencies.length; i++)
    {
      if (histArray[i] == null)
      {
        histArray[i] = "";
      }

      for (int k = 0; k < frequencies[i]; k++)
      {
        histArray[i] += "*";
      }//end inner for
    }//end outter for

    for (int i = 0; i < histArray.length; i++)
    {
      System.out.println(ALPHABET[i] + "|" + histArray[i]);
    }//end for
  }//end hist

//****************************//
// KeyWord Processing Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//****************************//
  // 6) validate the keyword and return the shift
  /**
   * Method Name: checkKeywordInArray()
   * Purpose: private class method that checks if the keyword entered is equivalent to the current validKeyword.
   * Accepts: String keyword
   * Returns: void, but runs the encipher method <=> the keyword is in the array.
   * Date: nov 144, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   *
   * (notes) this method acts as a boolean value that returns a number. if the call is correct then "true" = shift
   *          else the call is "false" = 0 and no shift is made therefore the call must be re-accessed etc.
   */
  private static int getShift(String inputkeyword)
  {
    int shift = validKeyword.length() - (validKeyword.length() - 1); //guarantees that the shift will always be 1.
    if (inputkeyword.equals(validKeyword))
    {
      return shift;
    }
    else
    {
      inputkeyword = keyword();// recursive call provides a loop type of statement that is complete when
      getShift(inputkeyword);  // the call is not in the else block.
      return 0;
    }//end if
  }//end checkKeywordInArray

//*******************************//
// Encryption/Decryption Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//*******************************//
  // 7) create encipher method()
  /**
   * Method Name: encipher()
   * Purpose: private class method that is used to encipher text and print the contents of the enciphered text along
   *          with the inputted text.
   * Accepts: a string of non-ciphered text and the shift.
   * Returns: void, returns the enciphered and current text
   * Date: nov 15, 2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void encipher(String inputWord, int shift)
  {
    //variable section
    String encypheredText = "";
    String encypheredText_output;

    //loop section for enciphering.
    for (int i = 0; i < inputWord.length(); i++)
    {
      //cycles all chars to the right of shift.
      char charInWord = (char) (inputWord.charAt(i) + shift);// casting is to a char the values is defined as UNICODE.
      if (charInWord > 'z')
      { // if past at last point in char alphabet the loop around according to shift.
        encypheredText += (char) (inputWord.charAt(i) - (26 - shift));
        /*
        * ASCII values from 65 to 90 inclusive are deducted shifted by the shift and
        * and or looped around. since the chars will always be uppercase the values of the chars
        * will always be within the interval of [65,90].
        */
      }
      else
      { // else set normal shift for chars before looping around
        encypheredText += (char) (inputWord.charAt(i) + shift);
      }//end if

    }//end for

    if(shift != 0)
    {
      encypheredText_output = encypheredText.replace("!", " ").toUpperCase();

      System.out.println("\nThe plaintext and enciphered text are as follows:");
      System.out.println(encypheredText_output);
      System.out.println(inputWord + "\n");
    }

  }//end encipher()


  // 8) create decipher method()
  /**
   * Method Name: decipher()
   * Purpose:private class method that is used to decipher text and print the contents of the deciphered text along
   *         with the inputted text.
   * Accepts: String of cipher text and the shift.
   * Returns:
   * Date:
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void decipher(String inputWord, int shift)
  {
    //variable section
    String decipheredText = "";
    String decipheredText_output;

    //loop section for decyphering.
    for (int i = 0; i < inputWord.length(); i++)
    {
      //cycles all chars to the left of shift.
      char charInWord = (char) (inputWord.charAt(i) - shift);// casting is to a char the values is defined as UNICODE.
      if (charInWord > 'z')
      {
        decipheredText += (char) (inputWord.charAt(i) + (26 + shift));
        /*
         * ASCII values from 65 to 90 inclusive are deducted shifted by the shift and
         * and or looped around the opposite way of the encipher code.since the chars will always be uppercase the
         * values of the chars will always be within the interval of [65,90].
         */
      }
      else
      {
        decipheredText += (char) (inputWord.charAt(i) - shift);
      }//end if
    }//end for

    // replaces the space box in unicode with a space.
    if(shift != 0)
    {
      decipheredText_output = decipheredText.replace("\u001F", " ").toUpperCase();

      System.out.println("\nThe deciphered  and ciphertext plaintext are as follows:");
      System.out.println(decipheredText_output);
      System.out.println(inputWord.toUpperCase() + "\n");
    }
  }//end decipher()

//********//
// Runner //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//********//
  //9) method to run enciphering operations
  /**
   * Method Name: fromUserEncipher()
   * Purpose: private class method used to run the ENCIPHER steps from user input section
   * Accepts: an int
   * Returns: nothing, runs the steps to encipher the message.
   * Date: Nov 22,2018.
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void fromUserEncipher(int choiceMenu)
  {
    inputWord = getText(choiceMenu);
    inputkeyword = keyword();
    shift = getShift(inputkeyword);
    encipher(inputWord, shift);

    //finds the frequency of the letters.
    int[] freq = getFrequency(inputWord);
    printFrequencies(freq, inputWord);
    hist(freq);

  }//end fromUserEncipher()


  //10) method to run deciphering operations from user
  /**
   * Method Name: fromUserDecipher()
   * Purpose: private class method used to run the steps for decoding a message from the user
   * Accepts: an int from encipherChoice()
   * Returns: output of methods and the final decoded message.
   * Date: nov 25, 2018.
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void fromUserDecipher(int choiceMenu)
  {
    inputWord = getText(choiceMenu);
    inputkeyword = keyword();
    shift = getShift(inputkeyword);
    decipher(inputWord, shift);
  }//end fromUserDecipher()


  // 11) method to run deciphering operation from datafile.
  /**
   * Method Name: fromDataDecipher()
   * Purpose: private class method used to run the steps for decoding a message from a datafile.
   * Accepts: an int from encipherChoice()
   * Returns: output of methods and the final decoded message.
   * Date: nov 25, 2018.
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void fromDataDecipher(int choiceMenu)
  {
    inputtedFileName = validateFileName();
    file = readFile(inputtedFileName);
    inputkeyword = keyword();
    shift = getShift(inputkeyword);
    decipher(file, shift);
  }//end fromDataDecipher()

}//end D_H_Project_Methods.java
