/*
 * Project Name: D_H_Regular_Cipher.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/7/2018 | Time: 10:44 PM
 *
 * PSEUDO-CODE:
 *    1)
 *
 */
package FinalProject.CeasarSaladCipher;

public class D_H_Regular_Cipher
{
  public static void main(String[] args)
  {
    // 3) Program explanation.
    System.out.println("This program will help you encipher a message or decipher a coded message.");
    System.out.println("\t\t//*********************************//");
    System.out.println("\t\t// Bill the keyword is ---> qwerty //");
    System.out.println("\t\t//*********************************//\n");

    D_H_Project_Methods.encyptionChoice();

  }//end main()
}//end Main class
