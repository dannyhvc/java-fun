///*
// * Project Name: D_H_Project_Methods.java
// * Purpose: method class that is used to minimize code.
// * Coder: Daniel Herrera (0881570) for Section 02
// * Date: 11/7/2018 | Time: 10:45 PM
// *
// * PSEUDO-CODE:
// *    1)
// *    2)
// *    3)
// *    4)
// *    5)
// *    6)
// *    7)
// *    8)
// *    9)
// *   10)
// */
//package FinalProject;
//
//import java.util.Scanner;
//
//import com.sun.java.util.jar.pack.Package.File;
//
//public class D_H_Project_Methods
//{
////******************//
//// Global Variables //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////******************//
//  /**
//   * Variable Name: validKeyword
//   * Purpose:
//   * Date:
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static int shift = 1;
//  private static String inputWord;
//  private static String inputkeyword;
//  public static boolean key;
//
////*****************//
//// Looping Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////*****************//
//  /**
//   * Method Name: encyptionChoice()
//   * Purpose: public class method that loops the choice in which there are forms to encrypt/decrypt.
//   *          (fromUser/fromData) and runs the series of methods that run the encryption type.
//   * Accepts: nothing
//   * Returns: void, but outputs the method functions depending on choice.
//   * Date: nov 18, 2018
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  public static void encyptionChoice()
//  {
//    Scanner scanner = new Scanner(System.in);
//    // 2) Declare Variables.
//    int flag = 0;
//    int choiceMenu;
//    int numChoice;
//
//    // 5) Create while loop to reevaluate choice after every iteration
//    while (flag == 0)
//    {
//      //user top level explanation
//      System.out.print
//          (
//              "(1) for enciphering (press enter)\n" +
//              "(2) for deciphering (press enter)\n" +
//              "(3) to exit\n" +
//              "Enter 1, 2, or 3: "
//          );
//
//      choiceMenu = scanner.nextByte(); // (edit) using byte to make program more efficient.
//      scanner.nextLine(); // buffer flush
//
//      // 6) Create switch to test choiceMenu condition
//      switch (choiceMenu)
//      {
//        case 1:
//          System.out.println("We will be enciphering a message.\n");
//          System.out.print
//              (
//                  "If ciphertext will be entered via keyboard, enter 1.\n" +
//                  "If ciphertext will be entered via file, enter 2.\n" +
//                  "Enter 1 or 2: "
//              );
//          numChoice = scanner.nextByte();
//          switch (numChoice)
//          {
//            case 1:
//              fromUserEncipher(choiceMenu);
//              break;
//            case 2:
//              fromDataEncipher(choiceMenu);
//              break;
//            default:
//              System.out.println("Sorry this is not an input.");
//          }//end switch
//          break;
//
//        case 2:
//          //insert decryption code here
//          System.out.println("We will be deciphering a message.\n");
//          System.out.print
//              (
//                  "If ciphertext will be entered via keyboard, enter 1.\n" +
//                  "If ciphertext will be entered via file, enter 2.\n" +
//                  "Enter 1 or 2: "
//              );
//          numChoice = scanner.nextByte();
//          switch (numChoice)
//          {
//            case 1:
//              fromUserDecipher(choiceMenu);
//              break;
//            case 2:
//              fromDataDecipher(choiceMenu);
//              break;
//            default:
//              System.out.println("Sorry this is not an input.");
//          }//end switch
//          break;
//
//        case 3:
//          flag += 1;
//          break;
//
//        default:
//          System.out.println("Error 101: the character you typed in " +
//              "does not belong to the selection\n" +
//              "please try a selection of type (1,2,3)!");
//      }//end switch
//    }//end ---> while
//    scanner.close(); // house keeping
//  }
//
////***************//
//// Input Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////***************//
//  /**
//   * Method Name: infoMessageENC
//   * Purpose: public class method that prints out a message to the console
//   * Accepts: nothing
//   * Returns: void
//   * Date: nov 18, 2018
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void infoMessageENC()
//  {
//    System.out.print("Enter the plaintext message you wish to encipher: ");
//  }//end infoMessageEN()
//
//  /**
//   * Method Name:
//   * Purpose: public class method that prints out a message to the console
//   * Accepts: nothing
//   * Returns: void
//   * Date: nov 18, 2018
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void infoMessageDEC()
//  {
//    System.out.print("Enter the plaintext message you wish to decipher: ");
//  }//end infoMessageDEC()
//
//  /**
//   * Method Name: inputWordForCypher
//   * Purpose: public class method that gets the non-ciphered input from user
//   * Accepts: nothing
//   * Returns: String
//   * Date: nov 14, 2018
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static String getText(int choiceMenu)
//  {
//    //creates scanner obj
//    Scanner scanner = new Scanner(System.in);
//
//    //checks if the display message should be for enciphering or deciphering.
//    if (choiceMenu == 1)
//    {
//      infoMessageENC();
//    }
//    if (choiceMenu == 2)
//    {
//      infoMessageDEC();
//    }
//
//    //input section
//    String inputWord = scanner.nextLine().toUpperCase();
//    scanner.close();
//
//    return inputWord;
//  }//end inputWordForCypher()
//
//  /**
//   * Method Name: keyword()
//   * Purpose: public class method that
//   * Accepts:
//   * Returns:
//   * Date:
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static String keyword()
//  {
//    Scanner scanner = new Scanner(System.in); //creates a scanner
//    String keyword; //declare variables
//    System.out.print("Enter a keyword of only letters, with no digits, spaces, or punctuation marks: "); //input section
//    keyword = scanner.nextLine().toUpperCase();
//    scanner.close();
//
//    return keyword; //output
//  }//end keyword()
//
////******************//
//// Datafile section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////******************//
//
////****************************//
//// KeyWord Processing Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////****************************//
//  /**
//   * Method Name: checkKeywordInArray()
//   * Purpose: public class method that checks if the keyword entered is equivalent to the current validKeyword.
//   * Accepts: String keyword
//   * Returns: void, but runs the encipher method <=> the keyword is in the array.
//   * Date: nov 144, 2018
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static int getShift(String inputkeyword)
//  {
//    String validKeyword = "QWERTY";
//    if (inputkeyword.equals(validKeyword))
//    {
//      return inputkeyword.length();
//    }
//    else
//    {
//      inputkeyword = keyword();
//      getShift(inputkeyword);
//    }//end if
//  }//end checkKeywordInArray
//
////*******************************//
//// Encryption/Decryption Section //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////*******************************//
//  /**
//   * Method Name: encipher()
//   * Purpose: public class method that is used to encipher text
//   * Accepts: a string of non-ciphered text
//   * Returns: void
//   * Date: nov 15, 2018
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void encipher(String inputWord, int shift)
//  {
//    //variable section
//    String encypheredText = "";
//    String encypheredText_output;
//
//    //loop section for encyphering.
//    for (int i = 0; i < inputWord.length(); i++)
//    {
//      //cycles all chars to the right of shift.
//      char c = (char) (inputWord.charAt(i) + shift);
//      if (c > 'z')
//      { // if past at last point in char alphabet the loop around according to shift.
//        encypheredText += (char) (inputWord.charAt(i) - (26 - shift));
//      }
//      else
//      { // else set normal shift for chars before looping around
//        encypheredText += (char) (inputWord.charAt(i) + shift);
//      }//end if
//
//    }//end for
//
//    encypheredText_output = encypheredText.replace("!", " ").toUpperCase();
//
//    System.out.println("\nThe plaintext and enciphered text are as follows:");
//    System.out.println(encypheredText_output);
//    System.out.println(inputWord + "\n");
//
//  }//end encipher()
//
//  /**
//   * Method Name: decipher()
//   * Purpose:
//   * Accepts:
//   * Returns:
//   * Date:
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void decipher(String inputWord, int shift)
//  {
//    //variable section
//    String decipheredText = "";
//    String decipheredText_output;
//
//    //loop section for decyphering.
//    for (int i = 0; i < inputWord.length(); i++)
//    {
//      //cycles all chars to the left of shift.
//      char c = (char) (inputWord.charAt(i) - shift);
//      if (c > 'z')
//      {
//        decipheredText += (char) (inputWord.charAt(i) + (26 + shift));
//      }
//      else
//      {
//        decipheredText += (char) (inputWord.charAt(i) - shift);
//      }//end if
//    }//end for
//
//    // replaces the space box in unicode with a space.
//    decipheredText_output = decipheredText.replace("\u001F", " ").toUpperCase();
//
//    System.out.println("\nThe deciphered  and ciphertext plaintext are as follows:");
//    System.out.println(decipheredText_output);
//    System.out.println(inputWord.toUpperCase() + "\n");
//  }//end decipher()
//
////********//
//// Runner //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
////********//
//
////ENC:
//  /**
//   * Method Name: fromUserEncipher()
//   * Purpose: public class method used to run the ENCIPHER steps from user input section
//   * Accepts: an int
//   * Returns: nothing, runs the steps to encipher the message.
//   * Date: Nov 22,2018.
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void fromUserEncipher(int choiceMenu)
//  {
//    inputWord = getText(choiceMenu);
//    inputkeyword = keyword();
//    shift = getShift(inputkeyword);
//    encipher(inputWord, shift);
//  }
//
//  /**
//   * Method Name: fromDataEncipher()
//   * Purpose: public class method used to run the DECIPHER steps from user input section
//   * Accepts: an int
//   * Returns: nothing, runs the steps to decipher the message.
//   * Date: Nov 22, 2018.
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void fromDataEncipher(int choiceMenu)
//  {
//    System.out.println("CODE FOR fromDataEncipher()");
//  }
//
////DEC:
//  /**
//   * Method Name: fromUserDecipher()
//   * Purpose:
//   * Accepts:
//   * Returns:
//   * Date:
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void fromUserDecipher(int choiceMenu)
//  {
//    inputWord = getText(choiceMenu);
//    inputkeyword = keyword();
//    shift = getShift(inputkeyword);
//    decipher(inputWord, shift);
//  }
//
//  /**
//   * Method Name: fromDataDecipher()
//   * Purpose:
//   * Accepts:
//   * Returns:
//   * Date:
//   * Coder: Daniel Herrera (0881570) for section 02.
//   */
//  private static void fromDataDecipher(int choiceMenu)
//  {
//    System.out.println("CODE FOR fromDataDecipher()");
//  }
//
//}//end *========**=======* class *========**=======* *========**=======* *========**=======* *========**=======* *=====*
//
//
//
//
//
//// standard method documentation header that should appear at the top of each method
///**
// * Method Name:
// * Purpose:
// * Accepts:
// * Returns:
// * Date:
// * Coder: Daniel Herrera (0881570) for section 02.
// */
