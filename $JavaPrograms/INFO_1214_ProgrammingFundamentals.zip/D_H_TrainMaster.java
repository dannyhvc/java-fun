/*
 * Project Name: D_H_TrainMaster.java
 * Purpose: this program is used to measure the amount of weight in each car of a freight train and make sure that
 *          two consecutive cars do not exceed the weight limit of 200 Metric tons. As well as giving the total weight
 *          for the train and its cars.
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 12/13/2018 | Time: 11:04 AM
 *
 * PSEUDO-CODE:
 *    1) create a validation loop of for # of cars entry in between 10-30 (inclusive)
 *    2) create trainArray of type int to hold the weight of the engine and the weight of each car.
 *    3) add ENGINE_WEIGHT into spot 0 of the trainArray and loop random weights between 30 - 135 into the trainArray.
 *    4) make method printTrainArray to display the weights of each individual car.
 *    5) call method testWeightDistribution() to test if the weights of adjacent pairs exceeds 200 metric tons.
 *    6) print out total weight from inputted method getTotalWeight in a display message.
 */
import java.util.Scanner;

public class D_H_TrainMaster
{
  public static void main(String[] args)
  {
    //TODO code
    //Create a Scanner obj
    Scanner scanner = new Scanner(System.in);

    //declare and initialize constants.
    final int ENGINE_WEIGHT = 70;
    final int MAX_CAR_WEIGHT = 135;
    final int MIN_CAR_WEIGHT = 30;

    //declare variables
    int numberOfCars;
    int trainArray[];
    int randomCarWeights;
    int totalWeight;

    //prints out program explanation
    System.out.println("Freight Train Load Tester\n");
    System.out.println("This program will analyze the weight distribution of rail cars in a simulated train");
    System.out.println("to determine if it will meet the bridge load limit requirements\n");

    //1) create a validation loop of for # of cars entry in between 10-30 (inclusive)
    System.out.print("Enter the number of cars in the train: ");
    numberOfCars = scanner.nextInt();
    while(numberOfCars < 10 || numberOfCars > 30)
    {
      System.out.println("Invalid number of cars. Please try again.");
      System.out.print("Enter the number of cars in the train: ");
      numberOfCars = scanner.nextInt();
    }//end while
    scanner.close();// good house keeping

    //2) create trainArray of type int to hold the weight of the engine and the weight of each car.
    trainArray = new int[numberOfCars + 1]; //add one to accommodate for the engine.

    //3) add ENGINE_WEIGHT into spot 0 of the trainArray and loop random weights between 30 - 135 into the trainArray.
    trainArray[0] = ENGINE_WEIGHT;
    for (int i = 1; i < trainArray.length; i++) //starting @ 1 to not change the value of the ENGINE_WEIGHT.
    {
      randomCarWeights = (int) (Math.random() * (MAX_CAR_WEIGHT - MIN_CAR_WEIGHT + 1) + MIN_CAR_WEIGHT);
      trainArray[i] = randomCarWeights;
    }//end for

    //4) call method printTrainArray() to display the weights of each individual car.
    printTrainArray(trainArray);

    //5) call method testWeightDistribution() to test if the weights of adjacent pairs exceeds 200 metric tons.
    testWeightDistribution(trainArray);

    //6) print out total weight from inputted method getTotalWeight in a display message.
    totalWeight = getTotalWeight(trainArray);
    System.out.println("\nThe total weight of the train is " + totalWeight + " metric tons.");

    //end program statement
    System.out.println("\n\n<===END-PROGRAM===>");

  }//end main()

  /**
   * Method Name: printTrainArray()
   * Purpose: private class method that will print the formatted contents of the trainArray.
   * Accepts: the int[] trainArray.
   * Returns: void, prints the values in the array
   * Date: 12/13/2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void printTrainArray(int[] trainArray)
  {
    //print output message for user
    System.out.println("\nHere are the weights in metric tons of all parts of the simulated train: \n");
    System.out.println("Engine: " + trainArray[0]);

    //loop through array and print the weights in each spot.
    for (int i = 1; i < trainArray.length; i++) //starting at 1 to skipping the ENGINE spot in the array.
    {
      System.out.println("Car " + i + ": " + trainArray[i]);
    }//end for
  }//end printTrainArray()


  /**
   * Method Name: testWeightDistribution()
   * Purpose: private class method used to test if the adjacent elements in the trainArray exceed WARNING_WEIGHT (200)
   * Accepts: int[] trainArray
   * Returns: void, prints out that there's an overload of weight and the positions of the adjacent pairs that have
   *          overloaded weight
   * Date: 12/13/2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static void testWeightDistribution(int[] trainArray)
  {
    //declare use names
    final int WARNING_WEIGHT = 200;
    int warnings = 0;

    //loop through the trainArray to find adjacent weights
    for (int i = 0; i < trainArray.length; i++)
    {
      if(i == 0 && (trainArray[i] + trainArray[i+1]) > WARNING_WEIGHT)
      {
        // this condition is a special case where the engine and the car 1 are > WARNING_WEIGHT
        System.out.println("WARNING: The engine and car 1 EXCEED the two-care weight limit at " +
            (trainArray[i] + trainArray[i+1]) + "tons");

        //since we wanna check if there are warnings in the simulation we make sure that we add 1 to the warnings
        // counter to make sure we do not miss inform the final exclusion block.
        warnings += 1;

      }
      else if ((i != trainArray.length - 1) && (trainArray[i] + trainArray[i+1]) > WARNING_WEIGHT)
      {
        //check if any of the cars in any other train are exceed the WARNING_WEIGHT and prints the respective pairs
        //that have exceed the limit.
        System.out.println("WARNING: Cars " + i + " and " + (i+1) + " EXCEED the two-care weight limit at "+
            (trainArray[i] + trainArray[i+1]) + " tons");
        warnings += 1;

      }
      else if (warnings == 0 && i == (trainArray.length - 1))
      {
        System.out.println("No weight distribution problems found on this train.");
      }//end if-elseif-else block
    }//end for
  }//end testWeightDistribution


  /**
   * Method Name: getTotalWeight()
   * Purpose: private class method the gets the sum of all the weights in the trainArray
   * Accepts: int[] trainArray
   * Returns: int totalWeight, which is the sum of all the elements in the array.
   * Date: 12/13/2018
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  private static int getTotalWeight(int[] trainArray)
  {
    // creating a variable to store the total weight.
    int totalWeight = 0;
    //looping through the array and adding each element into the totalWeight variable to get the total sum.
    for (int i = 0; i < trainArray.length; i++)
    {
      totalWeight += trainArray[i];
    }//end for
    return totalWeight;
  }//end getTotalWeight

}//end Main class
