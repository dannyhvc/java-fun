/*
* Introduction to gui obj types.
 */

package SwingTing.packGUI2;

import javax.swing.*;
import java.awt.*;

public class $1_Swing_intro extends JFrame
{
  public static void main(String[] args)
  {
    new $1_Swing_intro();
  }//end main

  public $1_Swing_intro() //constructor
  {
    //sets the size of the gui
    this.setSize(400,400);
    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension dim = tk.getScreenSize();
    this.setResizable(false);

    //creates the gui centered in the screen.
    int xPos = (dim.width / 2) - (this.getWidth() / 2);
    int yPos = (dim.height / 2) - (this.getHeight() / 2);

    //setLocation of the gui, and adds the title.
    this.setLocation(xPos, yPos);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes the program on exit
    this.setTitle("DanTheMan");

    //label STUFF
    //creates new panel obj
    JPanel thePanel = new JPanel();

    //adds a label obj
    JLabel label1 = new JLabel("tell me something");
    label1.setToolTipText("Does't do anything?");//makes a tooltip when you hover over the text
    thePanel.add(label1);//add the label to the panel.

    //button STUFF
    //creates a button obj
    JButton button1 = new JButton("Send");
    //(note) code bellow make this not look like a button.
    //button1.setBorderPainted(false);
    //button1.setContentAreaFilled(false);
    button1.setText("NewButton");
    button1.setToolTipText("BigG");
    thePanel.add(button1);//adds the button to the panel

    //txt field STUFF
    //creates a textfld obj
    JTextField textField1 = new JTextField("type here", 15);
    textField1.setColumns(10);
    textField1.setToolTipText("It's a text feild");
    textField1.requestFocus();//highlights the text to delete
    thePanel.add(textField1);//adds the text field to the panel.

    //txt area STUFF
    //creates a txtArea obj
    JTextArea textArea1 = new JTextArea(15,20);//not in pixels: its in letter sizes
    textArea1.setText("Just a whole bunch of text thats important.");
    textArea1.setLineWrap(true);//make the word stay in the area.
    textArea1.setWrapStyleWord(true);//make word stay intact
    //textArea1.append(@param);
    //scroll bars: part of the txt area
    JScrollPane jScrollPane1 =
        new JScrollPane(textArea1, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    thePanel.add(jScrollPane1);

    //makes the panel visible to the gui.
    this.add(thePanel);
    //make the gui visible to the user.
    this.setVisible(true);
  }
}//end class
