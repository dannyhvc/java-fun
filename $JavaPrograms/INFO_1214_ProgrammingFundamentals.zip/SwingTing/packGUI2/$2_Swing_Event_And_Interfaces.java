/*
 * lesson on gui even handling. Ways to use listeners and short cut ways to
 * to use interfaces.
 */

package SwingTing.packGUI2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class $2_Swing_Event_And_Interfaces extends JFrame
{
  JButton button1;
  JTextField jTextField1;
  JTextArea jTextArea1;
  int buttonClicked;

  public static void main(String[] args)
  {
    new $2_Swing_Event_And_Interfaces();
  }//end main

  private $2_Swing_Event_And_Interfaces()
  {
    //sets the size of the gui
    this.setSize(400, 400);
    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension dim = tk.getScreenSize();
    this.setResizable(false);

    //creates the gui centered in the screen.
    int xPos = (dim.width / 2) - (this.getWidth() / 2); //window of screen /2 and window of window /2 to find pos.
    int yPos = (dim.height / 2) - (this.getHeight() / 2);

    //setLocation of the gui, and adds the title.
    this.setLocation(xPos, yPos);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes the program on exit
    this.setTitle("theSecondFrame");

    //label STUFF
    //creates new panel obj
    JPanel thePanel = new JPanel();

    //adds a label obj
    JLabel label1 = new JLabel("tell me something");
    label1.setToolTipText("Does't do anything?");//makes a tooltip when you hover over the text
    thePanel.add(label1);//add the label to the panel.

    //button STUFF
    //creates a button obj
    JButton button1 = new JButton("CLick here");
    //(note) code bellow make this not look like a button.
    //button1.setBorderPainted(false);
    //button1.setContentAreaFilled(false);
    ListenForButton lForButton = new ListenForButton();
    button1.addActionListener(lForButton);
    thePanel.add(button1);//adds the button to the panel

    //txt field STUFF
    //creates a textfld obj
    JTextField textField1 = new JTextField("", 15);
    ListenForKeys lForKeys = new ListenForKeys();
    jTextField1.addKeyListener(lForKeys);
    thePanel.add(textField1);//adds the text field to the panel.

    //txt area STUFF
    //creates a txtArea obj
    JTextArea textArea1 = new JTextArea(15, 20);//not in pixels: its in letter sizes
    textArea1.setText("Tracking Events\n");
    textArea1.setLineWrap(true);//make the word stay in the area.
    textArea1.setWrapStyleWord(true);//make word stay intact
    //textArea1.append(@param);
    //scroll bars: part of the txt area
    JScrollPane jScrollPane1 =
        new JScrollPane(textArea1, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    thePanel.add(jScrollPane1);

    ListenForWindow lForWindow = new ListenForWindow();
    this.addWindowListener(lForWindow);

    //makes the panel visible to the gui.
    this.add(thePanel);
    //make the gui visible to the user.
    this.setVisible(true);

    ListenForMouse lForMouse = new ListenForMouse();
    thePanel.addMouseListener(lForMouse);

  }//end gui constructor

  //implement listeners
  private class ListenForButton implements ActionListener
  {
    @Override
    public void actionPerformed(ActionEvent e)
    {
      if (e.getSource() == button1)
      {
        buttonClicked++;
        jTextArea1.append("Button clicked" + buttonClicked + " times.\n");
      }//end if
    }
  }//end ListenForButton.

  private class ListenForKeys implements KeyListener
  {
    @Override
    public void keyPressed(KeyEvent e)
    {
      jTextArea1.append("Key Hit: " + e.getKeyChar() + "\n");//gets the char and places it in text area
    }

    @Override
    public void keyReleased(KeyEvent arg0)
    {

    }

    @Override
    public void keyTyped(KeyEvent arg0)
    {

    }

  }//end ListenForKeys.


  private class ListenForWindow implements WindowListener
  {

    @Override
    public void windowOpened(WindowEvent e)
    {
      jTextArea1.append("Window is opened");
    }

    @Override
    public void windowClosing(WindowEvent arg0)
    {

    }

    //this.dispose();
    @Override
    public void windowClosed(WindowEvent arg0)
    {

    }

    @Override
    public void windowIconified(WindowEvent arg0)
    {
      jTextArea1.append("Window is minimized");
    }

    @Override
    public void windowDeiconified(WindowEvent arg0)
    {
      jTextArea1.append("Window is in normal state.");
    }

    @Override
    public void windowActivated(WindowEvent arg0)
    {
      jTextArea1.append("Window is Active");
    }

    @Override
    public void windowDeactivated(WindowEvent arg0)
    {
      jTextArea1.append("Window is not active.");
    }
  }

  private class ListenForMouse implements MouseListener
  {

    @Override
    public void mouseClicked(MouseEvent e)
    {
      jTextArea1.append("Mouse Panel Pos: " + e.getX() + " " + e.getY() + "\n");
      jTextArea1.append("Mouse Screen Pos: " + e.getXOnScreen() + " " + e.getYOnScreen() + "\n");
      jTextArea1.append("Mouse Button: " + e.getButton() + "\n");
      jTextArea1.append("Mouse Clicks: " + e.getClickCount() + "\n");
    }

    @Override
    public void mousePressed(MouseEvent e)
    {
    }

    @Override
    public void mouseReleased(MouseEvent e)
    {

    }

    @Override
    public void mouseEntered(MouseEvent e)
    {

    }

    @Override
    public void mouseExited(MouseEvent e)
    {

    }
  }

}//end super