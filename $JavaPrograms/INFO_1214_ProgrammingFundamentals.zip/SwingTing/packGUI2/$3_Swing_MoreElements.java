

package SwingTing.packGUI2;//package SwingTing.packGUI2;
/*

import javax.swing.*;
import javax.swing.border.*; //used to edit borders.
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.event.*;
import java.text.NumberFormat; // formats numbers

public class $3_Swing_MoreElements extends JFrame {

  JButton button1;
  JLabel label1, label2, label3;
  JTextField textField1, textField2;
  JCheckBox dollarSign, commaSeparator;
  JRadioButton addNums, subtractNums, multNums, divideNums;
  JSlider howManyTimes;

  double num1, num2, totalCalc;

  public static void main(String[] args) {
    new $3_Swing_MoreElements();

  }//end main

  public $3_Swing_MoreElements() {
    this.setSize(400, 400);
    this.setLocationRelativeTo(null);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setTitle("My Third Frame");
    JPanel panel = new JPanel();

//creates button1
    button1 = new JButton("Calculate");
    ListenForButton listenForButton = new ListenForButton();
    button1.addActionListener(listenForButton);
    panel.add(button1);

//creates label1
    label1 = new JLabel("Number 1");
    panel.add(label1);

//creates textfeild1
    textField1 = new JTextField("", 5);
    panel.add(textField1);

//creates label2
    label2 = new JLabel("Number 2");

//creates textfeild1
    textField2 = new JTextField("", 5);
    panel.add(textField2);

//creates check boxes.
    dollarSign = new JCheckBox("Dollars");
    commaSeparator = new JCheckBox("Commas");
    panel.add(dollarSign);
    panel.add(commaSeparator, true); //(contraint: true) means that checkbox is checked by default.

//creates radio buttons
    addNums = new JRadioButton("Add");
    subtractNums = new JRadioButton("Subtract");
    multNums = new JRadioButton("Multiply");
    divideNums = new JRadioButton("Divide");

//puts all radio button into a group
    ButtonGroup operation = new ButtonGroup();
    operation.add(addNums);
    operation.add(subtractNums);
    operation.add(multNums);
    operation.add(divideNums);
//we made a new panel to set a border around all the Radio buttons.
    JPanel operPanel = new JPanel();
    Border operBorder = BorderFactory.createTitledBorder("Operation");
    operPanel.setBorder(operBorder);
    operPanel.add(addNums);
    operPanel.add(subtractNums);
    operPanel.add(multNums);
    operPanel.add(divideNums);
//we want default operation to be addition.
    addNums.setSelected(true);
//add operPanel to current panel.
    panel.add(operPanel);

//creates label3
    label3 = new JLabel("Preform How Many Times?");
    panel.add(label3);

//creates a silder
    howManyTimes = new JSlider(0, 99, 1);
    howManyTimes.setMinorTickSpacing(1);//puts small tick every 1 space
    howManyTimes.setMajorTickSpacing(10);//puts large tick every 10 spaces
    howManyTimes.setPaintTicks(true);//draws the ticks
    howManyTimes.setPaintLabels(true);//set number under the slider
//creates event listener for slider
    ListenForSlider listenForSlider = new ListenForSlider();
    howManyTimes.addChangeListener(listenForSlider);//creates action everytime the slider is changed
    panel.add(howManyTimes);

    this.add(panel);
    this.setVisible(true);
    textField1.requestFocus();

  }

  private class ListenForButton implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
      if (e.getSource() == button1) {

        try {
          num1 = Double.parseDouble(textField1.getText());
          num2 = Double.parseDouble(textField2.getText());

        } catch (NumberFormatException excep) {
          JOptionPane.showMessageDialog(
              $3_Swing_MoreElements.this,
              "Please Enter the Right Info",
              "Error", JOptionPane.ERROR_MESSAGE);
          System.exit(0);//closes the application
        }//end try

        if (addNums.isSelected()) {
          totalCalc = ListenForSlider.addNumber(num1, num2, howManyTimes.getValue());

        } else if (subtractNums.isSelected()) {
          totalCalc = ListenForSlider.subtractNumber(num1, num2, howManyTimes.getValue());

        } else if (multNums.isSelected()) {
          totalCalc = ListenForSlider.multiplyNumber(num1, num2, howManyTimes.getValue());

        } else {
          totalCalc = ListenForSlider.divideNumber(num1, num2, howManyTimes.getValue());
        }

        if (dollarSign.isSelected()) {
          NumberFormat numberFormat = NumberFormat.getCurrencyInstance();
          JOptionPane.showMessageDialog(
              $3_Swing_MoreElements.this,
              numberFormat.format(totalCalc),
              "Solution",
              JOptionPane.INFORMATION_MESSAGE);

        } else if (commaSeparator.isSelected()) {
          NumberFormat numberFormat = NumberFormat.getNumberInstance();
          JOptionPane.showMessageDialog(
              $3_Swing_MoreElements.this,
              numberFormat.format(totalCalc),
              "Solution",
              JOptionPane.INFORMATION_MESSAGE);

        } else {
          JOptionPane.showMessageDialog(
              $3_Swing_MoreElements.this,
              totalCalc,
              "Solution",
              JOptionPane.INFORMATION_MESSAGE);
        }

      }//end if[{}]

    }//end actionPreformed()
  }//end ListenForButton class.

  private class ListenForSlider implements ChangeListener {
    @Override
    public void stateChanged(ChangeEvent e) {
      if (e.getSource() == howManyTimes) {
        label3.setText("Preform How Many Time " + howManyTimes.getValue());
      }
    }

    public static double addNumber(double num1, double num2, int howManyTimes) {
      double total = 0;
      int i = 1;

      while (i <= howManyTimes) {
        total += (num1 + num2);
        i++;
      }
      return total;
    }

    public static double subtractNumber(double num1, double num2, int howManyTimes) {
      double total = 0;
      int i = 1;

      while (i <= howManyTimes) {
        total += (num1 - num2);
        i++;
      }
      return total;
    }

    public static double multiplyNumber(double num1, double num2, int howManyTimes) {
      double total = 0;
      int i = 1;

      while (i <= howManyTimes) {
        total += (num1 * num2);
        i++;
      }
      return total;
    }

    public static double divideNumber(double num1, double num2, int howManyTimes) {
      double total = 0;
      int i = 1;

      while (i <= howManyTimes) {
        total += (num1 / num2);
        i++;
      }
      return total;
    }

  }


}//end class







*/
