/*
 * Project Name: Main.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/5/2018 | Time: 3:43 PM
 */
package SwingTing.packGUI3;

import SwingTing.packGUI3.controller.MainFrameController;

public class Runner {
  public static void main(String[] args) {
    MainFrameController mainFrameController = new MainFrameController();
    mainFrameController.showMainFrameWindow();

  }//end main()   
}//end Main class
