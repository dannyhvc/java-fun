/*
 * Project Name: MainFrameController.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/5/2018 | Time: 3:52 PM
 */
package SwingTing.packGUI3.controller;

import SwingTing.packGUI3.view.MainFrame;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrameController {
  private MainFrame mainFrame;
  private JTextArea welcomTA;
  private JButton welcomeBtn;

  public MainFrameController() {
    initComponents();
    initListener();
  }

  private void initComponents() {
    mainFrame = new MainFrame();
    welcomeBtn = mainFrame.getWelcomeBtn();
    welcomTA = mainFrame.getWelcomTA();
  }

  public void showMainFrameWindow() {
    mainFrame.setVisible(true);
  }

  private void initListener() {
    welcomeBtn.addActionListener(new WelcomeBtnListener());
  }

  private class WelcomeBtnListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      welcomTA.append("Welcome!\n");
    }
  }
}//end Main class
