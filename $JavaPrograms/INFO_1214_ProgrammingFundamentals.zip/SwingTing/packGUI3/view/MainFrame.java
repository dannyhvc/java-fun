/*
 * Project Name: MainFrame.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/5/2018 | Time: 3:43 PM
 */
package SwingTing.packGUI3.view;

import javax.swing.*;

public class MainFrame extends JFrame {

  private JPanel mainPanel;
  private JButton welcomeBtn;
  private JTextArea welcomTA;

  public MainFrame() {
    setSize(500, 500);
    setContentPane(mainPanel);
    setLocationRelativeTo(null);
  }

  public JButton getWelcomeBtn() {
    return welcomeBtn;
  }

  public JTextArea getWelcomTA() {
    return welcomTA;
  }

}//end Main class
