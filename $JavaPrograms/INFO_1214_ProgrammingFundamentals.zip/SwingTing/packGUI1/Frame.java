/*
 * Project Name: Frame.java
 * Purpose: Template for swing frame gui set up.
 * Coder: Daniel Herrera 0881570 for Section 02
 * Date: 10/10/2018 | Time: 8:20 PM
 */
package SwingTing.packGUI1;

import javax.swing.*;

public class Frame {
  public static void main(String[] args) {
    JFrame frame = new JFrame("JFrame demo");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(320, 240);
    frame.setVisible(true);

  }//end main   
}//end class
