package SwingTing.packGUI1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ButtonClickedCounter extends JFrame
{
  public static void main(String[] args)
  {
    new ButtonClickedCounter();
  }//end main

  private ButtonClickedCounter()
  {
    this.setSize(100,100);

    Toolkit tk = Toolkit.getDefaultToolkit();
    Dimension dim = tk.getScreenSize();
    this.setResizable(false);

    //creates the gui centered in the screen.
    int xPos = (dim.width / 2) - (this.getWidth() / 2); //window of screen /2 and window of window /2 to find pos.
    int yPos = (dim.height / 2) - (this.getHeight() / 2);

    //setLocation of the gui, and adds the title.
    this.setLocation(xPos, yPos);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//closes the program on exit
    this.setTitle("Dan The Man With A Plan");

    //label STUFF
    //creates new panel obj
    JPanel thePanel = new JPanel();

    //button STUFF
    //creates a button obj
    JButton button1 = new JButton();
    button1.setText("jew");
    button1.addActionListener(new ActionListener()
    {
      int counter;
      @Override
      public void actionPerformed(ActionEvent e)
      {
        counter++;
        button1.setText("faggot: " + counter);
      }
    });
    thePanel.add(button1);//adds the button to the panel

    //makes the panel visible to the gui.
    this.add(thePanel);
    //make the gui visible to the user.
    this.setVisible(true);

  }//end constructor.
}//end Main class


