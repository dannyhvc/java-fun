/**
 * Program Name: Factorial_Recursive_1.java
 * Purpose: shows how to calculate a factorial value using a loop, with no recursion.
 *          NOTE: used a long return type so that we could avoid overflow of int at an input of 17.
 * Date:Nov 28, 2018
 */
import java.util.Scanner;
public class Factorial_Loop_Long_Version
{
	//CLASS WIDE SCOPE AREA
	//create a counter variable that can be seen in both the main() method and the
	//       calcFactorial() method.
	
	public static int counter = 0; 

	public static void main(String[] args)
	{
		// create Scanner
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a positive integer and I'll calculate its factorial value. ");
		int userInput = input.nextInt();
		
		//create a variable to 'catch' the value returned from the method
		long factorialValue = 1;
		
		//calculate using a loop
		for(int i = userInput; i > 0; i--)
		{
			factorialValue = factorialValue * i; //could also do factorialValue *= i;'
		}//end for
		
		//output
		System.out.println("The factorial value of " + userInput +
				                 " is " + factorialValue);
		
		

	}	//end main
	
}//end class











