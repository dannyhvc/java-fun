/*
 * Project Name: Preformace_BBLtester_1.java
 * Purpose: this program will find the runtime of any paticular 
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/21/2018 | Time: 3:26 PM
 */
package Methods_Chp6;
import java.util.Date;

public class Preformace_BBLtester_1
{
  public static void main(String[] args)
  {
    //constant for array size
    final int ARRAY_SIZE = 500_000;

    //create an array and fill t with random ints from 1 to array_size;
    int[] array = new int[ARRAY_SIZE];

    for(int i=0; i < array.length; i++)
    {
      array[i] = (int) (Math.random() * array.length + 1);
    }//end for

    //create a timer obj to act as a stop watch/
    long startTime = 0;
    long finishTime = 0;
    double elapsedTime = 0;
    // creates a date obj. when init it will contain a reading of the 
    // system clock in ms since jan 1,1970. which is windows "refrence time".
    Date start = new Date();
    startTime = start.getTime();
    System.out.println("STUB: time of start is " + startTime + "ms");

    //call the method
    MyToolbox.basicBubbleSort(array);

    //get the finish time using a second date obj
    Date finish = new Date();
    finishTime = finish.getTime();
    System.out.println("STUB: time of finsih is" + finishTime + "ms");

    //calc the elapsed time.
    elapsedTime = (finishTime-startTime) / 1000.0;

    //report
    System.out.println("time taken to do basic bblSort on array of size " 
    + ARRAY_SIZE + " was " + elapsedTime + " seconds.");

  }//end main()   
}//end Main class
