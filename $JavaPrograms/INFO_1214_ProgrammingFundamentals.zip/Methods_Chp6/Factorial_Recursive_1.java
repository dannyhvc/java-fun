/**
 * Program Name: Factorial_Recursive_1.java
 * Purpose: shows how to calculate a factorial value using a RECURSIVE METHOD that
 *          calls itself REPEATEDLY UNTIL IT REACHES IT STOPPING CASE (aka BASE CASE)
 * Coder: Bill Pulling for Sec01
 * Date:Nov 28, 2018
 */
import java.util.Scanner;
public class Factorial_Recursive_1
{
	//CLASS WIDE SCOPE AREA
	//create a counter variable that can be seen in both the main() method and the
	//       calcFactorial() method.
	
	public static int counter = 0; 

	public static void main(String[] args)
	{
		// create Scanner
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a positive integer and I'll calculate its factorial value. ");
		int userInput = input.nextInt();
		
		//create a variable to 'catch' the value returned from the method
		int factorialValue;
		
		//call the method calculateFactorial()
		factorialValue = calculateFactorial(userInput);
				
		//output
		System.out.println("The factorial value of " + userInput +
				                 " is " + factorialValue);
		System.out.println("The method was called " + counter + " times");
		
	}	//end main
	
	/**
	* Method Name: calculateFactorial()
	* Purpose: a public class method that calculates a factorial value using a recursive approach.
	* Accepts: an int whose factorial value is sought. 
	* Returns: an int that is the factorial value.
	* Date: Wed. Nov. 28. 2018
	* Coder: Bill Pulling
	*/
	public static int calculateFactorial(int n)
	{
		//increment counter
		counter++;		
		//STOPPING CASE
		if(n == 0)
		{
			return 1;
		}
		else //do a recursive call and reduce n by 1
		{
			return n * calculateFactorial(n-1);
		}
	}//end method	
}//end class











