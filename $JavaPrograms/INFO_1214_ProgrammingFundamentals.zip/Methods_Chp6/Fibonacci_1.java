/**
 * Program Name: Fibonacci_1.java
 * Purpose: shows how to calculate a FIBONACCI value using a RECURSIVE APPROACH, and it also
 *           will show why you SHOULD NEVER USE A RECURSIVE APPROACH TO DO A FIBONACCI CALCULATION.
 * Coder: Bill Pulling for Sec01
 * Date:Nov 28, 2018
 */
import java.util.Scanner;
public class Fibonacci_1
{
  //CLASS WIDE SCOPE AREA
	public static int counter = 0; // to record # of method calls made	
	
	public static void main(String[] args)
	{
		// prompt
		Scanner input = new Scanner(System.in);
		System.out.print("Enter a positive integer and I'll calculate its Fibonacci value. ");
		int index = input.nextInt();
		
		//variable to catch return
		int fibValue;
		
		//call the method
		fibValue = calcFibonacci(index);
		
		//output
		System.out.println("The fibonacci value of term at index# " + index + 
				                " is " + fibValue);
		System.out.println("For the index value " + index + " there were " + counter +
				               " method calls placed on the call stack.");
		

	}	//end main
	
	/**
	* Method Name: calcFibonacci()
	* Purpose: a public class method that calculates a Fibonacci value using a RECURSIVE approach
	* Accepts: an int that represents the INDEX NUMBER of the desired term in the series.
	* Returns: an int that is the fibonacci value at that index number.
	* Date: Wed Nov 28, 2018
	* Coder: Bill Pulling
	*/
  public static int calcFibonacci(int index)
  {
  	//increment call counter
  	counter++;
  	
  	//STOPPING CASE
  	if(index == 0 || index == 1)
  	{
  		return index;
  	}
  	else //do a recursive call
  	{
  		return calcFibonacci(index - 1) + calcFibonacci(index - 2);
  	}
  	
  }//end method
	
	
}
//end class





