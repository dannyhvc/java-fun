/*
 * Project Name: EnhancedBubbleSort_3.java
 * Purpose: shows the bubble sort algorithm
 *          (revision) replaces the four sepreate for loops with on nested for loop.
 *          (revision) changed the code so that once the largest is placed properly we don't
 *                     look at that element again.
 *          (revision) added some code to to count the number of swaps on a pass. if the # of swaps == 0,
 *                     it means the array is sorted.
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/21/2018 | Time: 2:46 PM
 */
package Methods_Chp6;

public class short_circuitBubbleSort_4
{
  public static void main(String[] args)
  {
    //test array
    int[] testArray = {20, 5, 15, 10, 25};
    System.out.println("order of elements in testArray is: ");
    MyToolbox.printArrayContents(testArray);
    int comparison_counter = 0;
    int swap_counter = 0;

    //outter loop for comparisons
    for(int outterCount=0; outterCount < testArray.length - 1; outterCount++)
    {
      //inner loop for comparisons
      //revision here:the magics happens in the lcc in of the inner loop.
      for (int innerCount = 0; innerCount < testArray.length - (outterCount + 1); innerCount++) // must do length-1 to avoid OutOfBounds.
      {
        comparison_counter++;
        swap_counter = 0;
        //compare adj vals
        if (testArray[innerCount] > testArray[innerCount + 1])
        {
          //revision #2: ++ swap_counter
          swap_counter++;
          //if true swapArrayELements
          MyToolbox.swapArrayElements(testArray, innerCount, innerCount + 1);
        }//end if
      }//end inner-for
      System.out.println("\nAfter pass " + (outterCount + 1) + " order of elements is ");
      MyToolbox.printArrayContents(testArray);
      //revison #2: do an if statement to see if a swap_counter is 0
      if(swap_counter == 0)
      {
        System.out.println("swap counter is zero after pass # " + outterCount +
            " doing a break on the outter loop.");
        break;
      }
    }//end outter-for

    System.out.println("total # comparsion made was " + comparison_counter);

  }//end main()   
}//end Main class
