/*
 * Project Name: basicBubbleSort_Method_tester.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/21/2018 | Time: 3:18 PM
 */
package Methods_Chp6;

public class BasicBubbleSort_Method_tester
{
  public static void main(String[] args)
  {
    // test array
    int[] array = {5,12,87,45,3,45,23,90};
    System.out.println("values in array before doing bblSort");
    MyToolbox.printArrayContents(array);
    
    //call method
    MyToolbox.basicBubbleSort(array);

    System.out.println("values in array after doing bblSort");
    MyToolbox.basicBubbleSort(array);

  }//end main()   
}//end Main class
