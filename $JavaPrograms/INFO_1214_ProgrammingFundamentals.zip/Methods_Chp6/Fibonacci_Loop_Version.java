/**
 * Program Name: Fibonacci_Loop_Version.java
 * Purpose: shows how to do a Fibonacci calculation using a loop, which is FAR FASTER than
 *          doing it recursively.
 *
 * Coder: Bill Pulling for Sec01
 * Date:Nov 28, 2018
 */

public class Fibonacci_Loop_Version
{

	public static void main(String[] args)
	{
		// variables
		long index = 123;
		
		long num1 = 0;
		long num2 = 1;
		long sumOfPreviousTwo = num1 + num2;
		
		//use a for loop
		for(int i = 1; i < index; i++)
		{
			sumOfPreviousTwo = num1 + num2;
			//swap them around
			num1 = num2;
			num2 = sumOfPreviousTwo;			
		}//end for
		
		//output
		System.out.println("Fibonacci value at index#" + index + " is " + sumOfPreviousTwo );
		
		
	}
	//end main
}
//end class