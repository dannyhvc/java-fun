/*
 * Project Name: Quick_Sort_Performance_Tester_5.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/29/2018 | Time: 11:58 AM
 */
package Methods_Chp6;
/*
 * Project Name: Quick_Sort_Preformance_Tester.java
 * Purpose: a tester class to test the efficiency of the MODIFIED QUICK SORT which
 *          is the type of sort used the the Arrays.sort() method.
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 11/27/2018 | Time: 7:07 PM
 */
import java.util.Date;
import java.util.Arrays;
class Quick_Sort_Performance_Tester_5
{

  public static void main(String[] args)
  {
    // constant for array size
    final int ARRAY_SIZE = 1000000;
    //create the array

    int[] testArray = new int[ARRAY_SIZE];

    //create an array and fill it with random ints from 1 to array_size
    for(int i = 0; i <  testArray.length; i++)
    {
      testArray[i] = (int)(Math.random() * testArray.length + 1);
    }//end for

    //create some variables and  a Date object to act as a stopwatch
    long startTime = 0;
    long finishTime = 0;
    double elapsedTime = 0;

    //create a Date object. When instantiated, it will contain the reading of the system
    // clock in milliseconds since Jan. 1, 1970, which is Windows "reference time".
    Date start = new Date();
    startTime = start.getTime();
    System.out.println("STUB: time of start is " + startTime + " milliseconds.");

    //REVSISION: call the Arrays.sort() method
    Arrays.sort(testArray);

    //get the finish time using a second Date object
    Date finish = new Date();
    finishTime = finish.getTime();
    System.out.println("STUB: time of finish is " + finishTime + " milliseconds.");

    //calculate elapsed time
    elapsedTime = (finishTime - startTime) / 1000.0;//using 1000.0 to avoid integer division

    //report
    System.out.println("Time taken to do a MODIFIED QUICK SORT USED BY " +
        "\nArrays.sort() on array of size " + ARRAY_SIZE +
        " was " + elapsedTime + " seconds.");


  }//end main
}//end class

