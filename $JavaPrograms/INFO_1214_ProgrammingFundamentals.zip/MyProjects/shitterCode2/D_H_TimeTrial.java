/*
 * Project Name: D_H_TimeTrial.java
 * Purpose: this program
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 12/12/2018 | Time: 8:30 PM
 */
package MyProjects.shitterCode2;
import java.util.Scanner;
import java.util.Arrays;

public class D_H_TimeTrial
{
  public static void main(String[] args)
  {
    //Create a scanner
    Scanner scanner = new Scanner(System.in);

    //define constants
    final int MAX_TIME = 60;
    final int MIN_TIME = 0;

    //Declare variables.
    int inputLaps;
    double splitTime;
    double max;
    double min;
    double avg;
    double raceTime;
    double[] stDevArray;

    //Step 2: Your program will first explain that it will calculate and display some statistics about the
    // split-times you enter. (See sample output.)
    System.out.println("Time-Trial Statistics Program\n");
    System.out.println(
        "This program will ask you to input split-times for each lap or length of a race. The\n" +
        "program will then calculate some basic statistics from the split-times.\n"
    );

    //Step 3: The program will then ask the user to enter how many lengths or laps (how many split-times) there were
    // in the race and create an array of this size of type double.
    System.out.print("Enter the number of laps or lengths in the race: "); inputLaps = scanner.nextInt();
    System.out.println();
    //Step 4: Use a loop to populate the array with values inputted by the user. Make sure to prompt the user
    // appropriately and to validate the user inputs to ensure all times are between 0 and 60 seconds inclusive.
    // (See sample output.)
    double[] splitTimeArray = new double[inputLaps];
    double[] copiedArray = new double[splitTimeArray.length];

    for (int i = 0; i < splitTimeArray.length; i++)
    {
      System.out.print("Time for lap or length #"+(i+1)+": "); splitTime = scanner.nextDouble();
      while(splitTime < MIN_TIME || splitTime > MAX_TIME)
      {
        System.out.println("Invalid input! Time must be between 0 and 60.");
        System.out.print("Time for lap or length #"+(i+1)+": "); splitTime = scanner.nextDouble();
      }//end while
      splitTimeArray[i] = splitTime;
    }//end for

    for (int i = 0; i < splitTimeArray.length; i++)
    {
      copiedArray[i] = splitTimeArray[i];
    }
    Arrays.sort(copiedArray);


    //Step 5: After all of the data has been entered, your program will call four methods listed below to do the data
    // analysis. The results will be returned to the main() method and the main() method will report these results
    // (See sample output.)
    //a. Call a method named getFastestSplit() that will take the split-times array as an argument and returns the
    // fastest split-time (smallest value) in the array.
    max = getFastestSplit(copiedArray);

    //b. Call a method named getSlowestSplit() that will take the split-times array as an argument and returns the
    // slowest split-time (largest value) in the array.
    min = getSlowestSplit(copiedArray);

    //c. Call a method named getAverageSplit() that will take the split-times array as an argument and returns the
    // average of all the split-time values in the array.
    avg = getAverageSplit(splitTimeArray);

    //d. Call a method named getRaceTime() that will take the split-times array as an argument and returns the total
    // race time asa the sum of all the split-times in the array.
    raceTime = getRaceTime(splitTimeArray);
    System.out.println("\nThe fastest split time was " + max + " Seconds");
    System.out.println("The slowest split time was " + min + " Seconds");
    System.out.println("The average split time was " + avg + " Seconds");
    System.out.println("The total race time was " + raceTime + " Seconds");

    //Step 6: Now call another method named getDeviationsArray() that will accept the split-times array as an argument.
    // It will return a parallel array of doubles containing the differences between each split-time and the average
    // split-time. Note that this method will NOT accept the average split time as an argument, but the method itself
    // can call the getAverageSplit() method to obtain the average splt-time. Once the array of differences
    // (or deviations) is returned from the method the program will print out the split times for each length/leg and
    // the deviations. (See sample output.)
    stDevArray = getDeviationsArray(splitTimeArray);
    System.out.println("\nHere are the split-times and deviations for each lap/length: \n");
    for (int i = 0; i < stDevArray.length; i++)
    {
      System.out.println("Lap or length #"+ (i+1) +": " + splitTimeArray[i] + " seconds " + "(" + stDevArray[i] + ")");
    }//end for

  }//end main()


  private static double getFastestSplit(double[] copiedArray)
  {
    return copiedArray[copiedArray.length - 1];
  }//end getFastestSplit()


  private static double getSlowestSplit(double[] copiedArray)
  {
    return copiedArray[0];
  }//end getSlowestSplit()


  private static double getAverageSplit(double[] splitTimeArray)
  {
    double sum = 0;
    for (int i = 0; i < splitTimeArray.length; i++)
    {
      sum += splitTimeArray[i];
    }
    return (double) Math.round((sum/splitTimeArray.length)*100) / 100;
  }//end getAverageSplit()


  private static double getRaceTime(double[] splitTimeArray)
  {
    double sum = 0;
    for (int i = 0; i < splitTimeArray.length; i++)
    {
      sum += splitTimeArray[i];
    }
    return sum;
  }//end getRaceTime()


  private static double[] getDeviationsArray(double[] splitTimeArray)
  {
    //declare variables
    double sum = 0;
    double stDev = 0;
    double[] stDevArray = new double[splitTimeArray.length];
    //get the avg
    for (int i = 0; i < splitTimeArray.length; i++)
    {
      sum += splitTimeArray[i];
    }//end for

    for (int i = 0; i < splitTimeArray.length; i++)
    {
      stDev = splitTimeArray[i] - (sum/splitTimeArray.length);
      stDevArray[i] = (double) Math.round((stDev)*100)/100;
    }//end for
    return stDevArray;
  }//end getDeviationsArray()

}//end Main class
