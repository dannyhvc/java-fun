/*
 * Project Name: CharCounter.java
 * Purpose: this program is meant to
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 12/2/2018 | Time: 9:33 AM
 */
package MyProjects.shitterCode2;

import java.util.Scanner;

public class CharCounter
{
  private static final char[] ALPHABET = {
      'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
      'W', 'X', 'Y', 'Z'};


  public static void main(String[] args)
  {
    // creates scanner obj
    Scanner scanner = new Scanner(System.in);
    //intro message.
    System.out.println("This is Dan's character counter program!");
    System.out.print("Enter the a phrase: ");

    String input = scanner.nextLine();
    String inputeroo = input.toUpperCase();

    // outs the frequencies of the letters
        int[] freq = getFrequency(inputeroo);
        printFrequencies(freq, inputeroo);
        hist(freq);
  }//end main()


  private static int[] getFrequency(String token)
  {
    int[] frequencyies = new int[ALPHABET.length];
    char[] karchar = token.toCharArray();

    //cycle through the length of the phrase.
    for (int i = 0; i < token.length(); i++)
    {
      if (Character.isLetter(karchar[i]))
      {
        frequencyies[(char) (karchar[i]) - 65] += 1;
      }//end if
    }//end for

    return frequencyies;
  }//end getFrequency


  private static void printFrequencies(int[] frequencies, String token)
  {
    System.out.println("The frequency of the set characters in " + '"' + token + '"' + " is as follows: ");

    for (int i = 0; i < frequencies.length; i++)
    {
      System.out.println("# of " + ALPHABET[i] + "'s is " + frequencies[i] + " or "
          + (Math.floor((frequencies[i] / (double) token.length()) * 10_000) / 100) + "%");
    }//end for
    System.out.println();
  }//end printFrequencies


  public static void hist(int[] frequencies)
  {
    System.out.println("<====SIMULATED-HISTOGRAM-OF-THE-FREQUENCIES====>");
    String[] histArray = new String[ALPHABET.length];
    for (int i = 0; i < frequencies.length; i++)
    {
      if (histArray[i] == null)
      {
        histArray[i] = "";
      }

      for (int k = 0; k < frequencies[i]; k++)
      {
        histArray[i] += "*";
      }//end inner for

    }//end outter for

    for (int i = 0; i < histArray.length; i++)
    {
      System.out.println(ALPHABET[i] + "|" + histArray[i]);
    }//end for
  }//end hist


}//end Main class
