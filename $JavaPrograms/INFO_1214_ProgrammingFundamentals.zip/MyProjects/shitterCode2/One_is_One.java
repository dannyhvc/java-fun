/*
 * Project Name: One_is_One.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 12/2/2018 | Time: 2:35 PM
 */
package MyProjects.shitterCode2;
import java.util.Scanner;

public class One_is_One
{
  public static void main(String[] args)
  {
    // create a scanner.
    Scanner scanner = new Scanner(System.in);

    // get input
    System.out.print("Enter an X-val for the expression 1 = x - (x - 1): ");
    double x = scanner.nextDouble();

    //print out the value.
    System.out.println("x = " + x);
    System.out.println("x - 1 = " + (x - 1));
    System.out.println("x - (x - 1) = " + x + " - " + "(" + (x-1) + ")");
    System.out.println("result: " + (x-(x-1)));


  }//end main()   
}//end Main class
