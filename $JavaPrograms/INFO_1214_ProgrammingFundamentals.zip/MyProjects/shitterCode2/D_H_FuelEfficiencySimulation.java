/*
 * Project Name: D_H_FuelEfficiencySimulation.java
 * Purpose: this program will calc the fuel efficiency of a car depending on the number of commuters each
 *          car will be have randomly generated distance and are assumed to be hybrids.
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 12/12/2018 | Time: 5:59 PM
 */
package MyProjects.shitterCode2;
import java.util.*;

public class D_H_FuelEfficiencySimulation
{
  public static void main(String[] args)
  {
    //TODO code
    //create a scanner obj
    Scanner scanner = new Scanner(System.in);

    //declare constants
    final int ELECTRIC_KM = 55;

    //Declare variables
    int numberOfCommuters;
    int[] distanceArray;
    double[] fuelUsedArray;
    double[] fuelEfficiencyArray;
    double avg_fuelUsed;
    double avg_fuelEff;

    //print to the reader program explanation.
    System.out.println("Fuel Efficiency Simulation");
    System.out.println(
        "\nThis program will generate a simulated group of commuters assigning them" +
        "\nrandom daily commutes. It will then calculate the fuel used daily and the" +
        "\ncombined fuel efficiency achieved by the new extended range electric car."
    );

    //Step 3: Ask the user to enter the number of commuters to use in the simulation.
    // The will be the size of the arrays used in the simulation.
    System.out.print("\nEnter the number of commuters: "); numberOfCommuters = scanner.nextInt();

    //Step 4: Create an array of type int called distanceArray
    // to hold the length of the daily commute for each commuter.
    distanceArray = new int[numberOfCommuters];

    //Step 5: Call a void method named getRandomDistances() that accept the int array as an argument and which
    // populates it with random integers in the range 10 km to 150 km.
    getRandomDistances(distanceArray);

    //Step 6: Create two more arrays of type double of the same size named fuelUsedArray and fuelEfficiencyArray.
    // These arrays are to be used as parallel arrays along with distanceArray such that elements at the same index
    // in each array will correspond to the same commuter.
    fuelUsedArray = new double[numberOfCommuters];
    fuelEfficiencyArray = new double[numberOfCommuters];

    //Step 7: Create a loop to populate the fuelUsedArray and fuelEfficiencyArray.
    // It should traverse the elements of the distanceArray and do the following:

    //a. If the distance of the commute is less than or equal to 55 km,
    // assign 0 for to the current element of fuelUsedArrray, otherwise call a method named calculateFuelUsed()
    // and assign the value returned to the current element of fuelUsedArrray. The calculateFuelUsed() method accepts
    // the distance traveled using gasoline (the distance of the commute minus 55) as a double, and returns the number
    // of Litres of fuel used as a double.
    for(int i=0; i < distanceArray.length; i++)
    {
      if(distanceArray[i] <= ELECTRIC_KM)
      {
        fuelUsedArray[i] = 0;

      }else
      {
       fuelUsedArray[i] = calculateFuelUsed(distanceArray[i] - ELECTRIC_KM);
      }//end if-else

    //b. Call another method named calculateEfficiency() which accepts two arguments: the fuel used as a double and
    // the total distance of the commute as an int. Assign the result to the current element of fuelEfficiencyArray.
      fuelEfficiencyArray[i] = calculateEfficiency(fuelUsedArray[i], distanceArray[i]);

    }//end for

    //Step 8: Call a void method called reportDetails() which accepts all three arrays as arguments and neatly prints
    // all the values in all three arrays to the screen in neat rows with a heading above it. (See sample output.)
    reportDetails(distanceArray, fuelUsedArray, fuelEfficiencyArray);

    //Step 9: Use a method called calculateAverage() which accepts an array of type double as its only argument and
    // returns the average value as a double. Call the method twice: once to calculate the average fuel used by the
    // commuters and again to calculate the average fuel efficiency achieved by the commuters. Report these averages.
    // (See sample output.)
    System.out.println("\nThe average fuel used is " + calculateAverage(fuelUsedArray) +
        " L and the average efficiency achieved is \n" + calculateAverage(fuelEfficiencyArray) + " L/100 km");

    //Step 10: Write the five methods, as described above, below your main method (not in a separate helper class).
    // Make sure to include a method documentation header for each method.
    // getRandomDistances()
    // calculateFuelUsed()
    // calculateEfficiency()
    // reportDetails()
    // calculateAverage()
    // LOOK BELOW.

  }//end main()


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date:
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static void getRandomDistances(int[] distanceArray)
  {
    int randomDistances;
    for(int i=0; i < distanceArray.length; i++)
    {
      randomDistances = (int) (Math.random() * (150 - 10 + 1) + 10);
      distanceArray[i] = randomDistances;
    }//end for
  }//end getRandomDistances()


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date:
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static double calculateFuelUsed(double distance)
  {
    final double GAS_FUEL_RATE = 6.2;
    return Math.round(((distance * GAS_FUEL_RATE) / 100) * 100.0) / 100.0;
  }//end calculateFuelUsed()


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date:
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static double calculateEfficiency(double fuelUsed, int distance)
  {
    return Math.floor((fuelUsed * 100 / distance) * 100) / 100;
  }//end calculateEfficiency()


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date:
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static void reportDetails(int[] distanceArray, double[] fuelUsedArray, double[] fuelEffeciencyArray)
  {
    System.out.println("Here are the group’s distance, fuel usage and fuel efficiency details...\n");

    for(int i=0; i < distanceArray.length;i++)
    {
      System.out.println(
          "Commuter " + (i+1) + ":\t\t" +
          distanceArray[i] + " km,\t\t" +
          fuelUsedArray[i] + " L\t\t" +
          fuelEffeciencyArray[i]+" L/100 km"
      );
    }//end for
  }//end reportDetails()


  /**
   * Method Name:
   * Purpose:
   * Accepts:
   * Returns:
   * Date:
   * Coder: Daniel Herrera (0881570) for section 02.
   */
  public static double calculateAverage(double[] array)
  {
    double avg_calc = 0;
    for(int i=0; i < array.length; i++)
    {
      avg_calc += array[i];
    }
    return Math.round((avg_calc/array.length) * 100.0) / 100.0;
  }//end calculateAverage()

}//end Main class
