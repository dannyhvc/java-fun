/*
 * Project Name: IntStreams_Testing.java
 * Purpose:
 * Coder: Daniel Herrera (0881570) for Section 02
 * Date: 12/11/2018 | Time: 9:08 PM
 */
package MyProjects.shitterCode2;
import java.util.stream.IntStream;

public class IntStreams_Testing
{
  // Driver code
  public static void main(String[] args)
  {
    int[] a = {1,2,3,4};

    boolean contains = IntStream.of(a).anyMatch(x -> x == 4);
    System.out.println("-> "+contains);

  }//end main()
}//end Main class
